package org.ideas2it.management.constant;

public class Constants {

    public static final String URL = "jdbc:mysql://localhost/employee?verifyServerCertificate=false&useSSL=true"; 
    public static final String SQL_USER_NAME = "root";
    public static final String SQL_PASSWORD = "Ram@i2it";
    public static final String TRAINER = "trainer";
    public static final String TRAINEE = "trainee";
    public static final String MANAGER = "manager";
    public static final String COMPANY_ID_PREFIX = "I2I";

}